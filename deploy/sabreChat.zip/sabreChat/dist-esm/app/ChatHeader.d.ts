export declare type ChatHeaderProps = {
    isParticipantsDisplayed: boolean;
    onEndChat(): void;
    setHideParticipants(hideParticipants: boolean): void;
};
export declare const ChatHeader: (props: ChatHeaderProps) => JSX.Element;
//# sourceMappingURL=ChatHeader.d.ts.map