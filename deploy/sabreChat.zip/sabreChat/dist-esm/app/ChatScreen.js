// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { ChatComposite, createAzureCommunicationChatAdapter, fromFlatCommunicationIdentifier } from '@azure/communication-react';
import { Stack } from '@fluentui/react';
import React, { useEffect, useRef, useState } from 'react';
import { ChatHeader } from './ChatHeader';
import { chatCompositeContainerStyle, chatScreenContainerStyle } from './styles/ChatScreen.styles';
import { createAutoRefreshingCredential } from './utils/credential';
import { fetchEmojiForUser } from './utils/emojiCache';
import { getBackgroundColor } from './utils/utils';
import { useSwitchableFluentTheme } from './theming/SwitchableFluentThemeProvider';
export const ChatScreen = (props) => {
    const { displayName, endpointUrl, threadId, token, userId, errorHandler, endChatHandler } = props;
    const adapterRef = useRef();
    const [adapter, setAdapter] = useState();
    const [hideParticipants, setHideParticipants] = useState(false);
    const { currentTheme } = useSwitchableFluentTheme();
    useEffect(() => {
        (() => __awaiter(void 0, void 0, void 0, function* () {
            const adapter = yield createAzureCommunicationChatAdapter({
                endpoint: endpointUrl,
                userId: fromFlatCommunicationIdentifier(userId),
                displayName: displayName,
                credential: createAutoRefreshingCredential(userId, token),
                threadId: threadId
            });
            adapter.on('participantsRemoved', (listener) => {
                // Note: We are receiving ChatParticipant.id from communication-signaling, so of type 'CommunicationIdentifierKind'
                // while it's supposed to be of type 'CommunicationIdentifier' as defined in communication-chat
                const removedParticipantIds = listener.participantsRemoved.map((p) => p.id.communicationUserId);
                if (removedParticipantIds.includes(userId)) {
                    const removedBy = listener.removedBy.id.communicationUserId;
                    endChatHandler(removedBy !== userId);
                }
            });
            adapter.on('error', (e) => {
                console.error(e);
                errorHandler();
            });
            setAdapter(adapter);
            adapterRef.current = adapter;
        }))();
        return () => {
            var _a;
            (_a = adapterRef === null || adapterRef === void 0 ? void 0 : adapterRef.current) === null || _a === void 0 ? void 0 : _a.dispose();
        };
    }, [displayName, endpointUrl, threadId, token, userId, errorHandler, endChatHandler]);
    if (adapter) {
        const onFetchAvatarPersonaData = (userId) => fetchEmojiForUser(userId).then((emoji) => new Promise((resolve) => {
            var _a;
            return resolve({
                imageInitials: emoji,
                initialsColor: (_a = getBackgroundColor(emoji)) === null || _a === void 0 ? void 0 : _a.backgroundColor
            });
        }));
        return (React.createElement(Stack, { className: chatScreenContainerStyle },
            React.createElement(Stack.Item, { className: chatCompositeContainerStyle },
                React.createElement(ChatComposite, { adapter: adapter, fluentTheme: currentTheme.theme, options: { topic: false }, onFetchAvatarPersonaData: onFetchAvatarPersonaData })),
            React.createElement(ChatHeader, { isParticipantsDisplayed: hideParticipants !== true, onEndChat: () => adapter.removeParticipant(userId), setHideParticipants: setHideParticipants })));
    }
    return React.createElement(React.Fragment, null, "Initializing...");
};
//# sourceMappingURL=ChatScreen.js.map