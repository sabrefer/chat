import { IButtonStyles, IIconProps } from '@fluentui/react';
export declare const chatHeaderContainerStyle: string;
export declare const leaveButtonStyle: string;
export declare const greyIconButtonStyle: string;
export declare const leaveIcon: IIconProps;
export declare const paneButtonContainerStyle: string;
export declare const largeLeaveButtonContainerStyle: string;
export declare const buttonWithIconStyles: IButtonStyles;
export declare const smallLeaveButtonContainerStyle: string;
export declare const leaveIconStyle: string;
//# sourceMappingURL=ChatHeader.styles.d.ts.map