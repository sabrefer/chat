export declare const chatScreenContainerStyle: string;
export declare const chatCompositeContainerStyle: string;
//# sourceMappingURL=ChatScreen.styles.d.ts.map