import { IButtonStyles, IStackTokens } from '@fluentui/react';
export declare const mainStackTokens: IStackTokens;
export declare const buttonsStackTokens: IStackTokens;
export declare const upperStackTokens: IStackTokens;
export declare const endChatContainerStyle: string;
export declare const endChatTitleStyle: string;
export declare const buttonStyle: string;
export declare const buttonWithIconStyles: IButtonStyles;
export declare const chatIconStyle: string;
export declare const bottomStackFooterStyle: string;
export declare const buttonTextStyle: string;
//# sourceMappingURL=EndChat.styles.d.ts.map