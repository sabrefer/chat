// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { DefaultButton, PrimaryButton, Stack, Link, Text } from '@fluentui/react';
import React, { useCallback, useState } from 'react';
import { bottomStackFooterStyle, buttonStyle, buttonWithIconStyles, buttonsStackTokens, chatIconStyle, endChatContainerStyle, endChatTitleStyle, mainStackTokens, upperStackTokens } from './styles/EndChat.styles';
import { Chat20Filled } from '@fluentui/react-icons';
import { getExistingThreadIdFromURL } from './utils/getExistingThreadIdFromURL';
import { joinThread } from './utils/joinThread';
export const EndScreen = (props) => {
    const leftCall = 'You left the chat';
    const goHomePage = 'Go to homepage';
    const rejoinChat = 'Rejoin chat';
    const rejoining = 'Rejoining...';
    const [isRejoiningThread, setIsRejoiningThread] = useState(false);
    const { rejoinHandler, userId, displayName } = props;
    const rejoinThread = useCallback(() => __awaiter(void 0, void 0, void 0, function* () {
        if (!isRejoiningThread) {
            const threadId = getExistingThreadIdFromURL();
            if (!threadId) {
                console.error('thread id is null');
                return;
            }
            yield joinThread(threadId, userId, displayName);
            setIsRejoiningThread(true);
            rejoinHandler();
        }
    }), [isRejoiningThread, displayName, userId, rejoinHandler]);
    const sabretoothLink = 'https://www.sabretoothtechnologiescom';
    return (React.createElement(Stack, { horizontal: true, wrap: true, horizontalAlign: "center", verticalAlign: "center", tokens: mainStackTokens, className: endChatContainerStyle },
        React.createElement(Stack, { tokens: upperStackTokens },
            React.createElement(Text, { role: 'heading', "aria-level": 1, className: endChatTitleStyle }, leftCall),
            React.createElement(Stack, { horizontal: true, wrap: true, tokens: buttonsStackTokens },
                React.createElement(PrimaryButton, { disabled: isRejoiningThread, className: buttonStyle, styles: buttonWithIconStyles, text: isRejoiningThread ? rejoining : rejoinChat, onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                        yield rejoinThread();
                    }), onRenderIcon: () => React.createElement(Chat20Filled, { className: chatIconStyle }) }),
                React.createElement(DefaultButton, { className: buttonStyle, styles: buttonWithIconStyles, text: goHomePage, onClick: props.homeHandler })),
            React.createElement("div", { className: bottomStackFooterStyle },
                React.createElement(Link, { href: sabretoothLink }, "Sabretooth Innovative Technologies"),
                "\u00A0Acclaimed Restaurant and Hospitality Software Solutions"))));
};
//# sourceMappingURL=EndScreen.js.map