declare const _default: () => JSX.Element;
export default _default;
//# sourceMappingURL=App.d.ts.map