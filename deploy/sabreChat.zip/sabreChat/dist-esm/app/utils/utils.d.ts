export declare const getChatSDKVersion: () => string;
export declare const getBuildTime: () => string;
export declare const CAT = "\uD83D\uDC31";
export declare const MOUSE = "\uD83D\uDC2D";
export declare const KOALA = "\uD83D\uDC28";
export declare const OCTOPUS = "\uD83D\uDC19";
export declare const MONKEY = "\uD83D\uDC35";
export declare const FOX = "\uD83E\uDD8A";
export declare const getBackgroundColor: (avatar: string) => {
    backgroundColor: string;
};
//# sourceMappingURL=utils.d.ts.map