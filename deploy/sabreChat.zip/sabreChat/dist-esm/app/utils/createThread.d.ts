export declare const createThread: () => Promise<string>;
//# sourceMappingURL=createThread.d.ts.map