/**
 *
 * The threadId of the current thread is extracted from the url
 * using URLsearchparams.
 *
 * @returns The current threadId as String
 *
 */
export declare const getExistingThreadIdFromURL: () => string | null;
//# sourceMappingURL=getExistingThreadIdFromURL.d.ts.map