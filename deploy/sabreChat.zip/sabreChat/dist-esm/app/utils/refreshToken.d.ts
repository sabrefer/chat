import { AbortSignalLike } from '@azure/core-http';
export declare const refreshTokenAsync: (userIdentity: string) => (abortSignal?: AbortSignalLike | undefined) => Promise<string>;
//# sourceMappingURL=refreshToken.d.ts.map