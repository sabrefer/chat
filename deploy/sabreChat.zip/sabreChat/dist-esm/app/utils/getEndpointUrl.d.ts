export declare const getEndpointUrl: () => Promise<string>;
//# sourceMappingURL=getEndpointUrl.d.ts.map