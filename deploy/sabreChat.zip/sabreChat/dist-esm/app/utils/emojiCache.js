// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
const emojiCache = new Map();
const getEmoji = (userId) => {
    const getTokenRequestOptions = {
        headers: { 'Content-Type': 'application/json' },
        method: 'GET'
    };
    return new Promise((resolve) => {
        fetch('/userConfig/' + userId, getTokenRequestOptions)
            .then((data) => {
            return data.json();
        })
            .then((json) => {
            resolve(json.emoji);
        })
            .catch((error) => {
            console.error('Failed at getting emoji, Error: ', error);
            // Emoji defaults to '' if there was an error retrieving it from server.
            resolve('');
        });
    });
};
/**
 * Returns emoji string to caller based on userId. If emoji already exists in cache, return the cached emoji. Otherwise
 * makes a server request to get emoji. The returned emoji is a Promise<string> which may or may not be resolved so
 * caller should await it. There could potentially be many awaits happening so we may need to consider a callback style
 * approach.
 *
 * @param userId
 */
export const fetchEmojiForUser = (userId) => {
    const emoji = emojiCache.get(userId);
    if (emoji === undefined) {
        const promise = getEmoji(userId);
        emojiCache.set(userId, promise);
        return promise;
    }
    else {
        return emoji;
    }
};
//# sourceMappingURL=emojiCache.js.map