export declare const getThreadId: () => string | null;
//# sourceMappingURL=getThreadId.d.ts.map