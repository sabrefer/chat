export declare const checkThreadValid: (threadId: string | null) => Promise<boolean>;
//# sourceMappingURL=checkThreadValid.d.ts.map