// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export const getThreadId = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const threadId = urlParams.get('threadId');
    return threadId;
};
//# sourceMappingURL=getThreadId.js.map