export declare const sendEmojiRequest: (identity: string, emoji: string) => Promise<void>;
//# sourceMappingURL=setEmoji.d.ts.map