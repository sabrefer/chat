export declare enum StatusCode {
    OK = 200,
    CREATED = 201
}
export declare const ENTER_KEY = 13;
//# sourceMappingURL=constants.d.ts.map