// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { StatusCode } from './constants';
export const checkThreadValid = (threadId) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (threadId === null) {
            console.log('Fail to validate thread id because thread id is null');
            return false;
        }
        const validationRequestOptions = { method: 'GET' };
        const validationResponse = yield fetch('/isValidThread/' + threadId, validationRequestOptions);
        return validationResponse.status === StatusCode.OK;
    }
    catch (error) {
        console.error('Failed at getting isThreadIdValid, Error: ', error);
        return false;
    }
});
//# sourceMappingURL=checkThreadValid.js.map