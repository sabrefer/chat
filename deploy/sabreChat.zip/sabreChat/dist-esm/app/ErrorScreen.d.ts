export interface ErrorEndCallProps {
    title: string;
    homeHandler(): void;
}
export declare const ErrorScreen: (props: ErrorEndCallProps) => JSX.Element;
//# sourceMappingURL=ErrorScreen.d.ts.map