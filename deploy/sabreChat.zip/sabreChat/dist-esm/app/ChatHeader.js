// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React from 'react';
import { DefaultButton, Icon, IconButton, mergeStyles, Stack } from '@fluentui/react';
import { People20Filled, People20Regular } from '@fluentui/react-icons';
import { buttonWithIconStyles, chatHeaderContainerStyle, greyIconButtonStyle, largeLeaveButtonContainerStyle, leaveButtonStyle, leaveIcon, leaveIconStyle, paneButtonContainerStyle, smallLeaveButtonContainerStyle } from './styles/ChatHeader.styles';
import { useTheme } from '@azure/communication-react';
export const ChatHeader = (props) => {
    const theme = useTheme();
    const leaveString = 'Leave';
    return (React.createElement(Stack, { horizontal: true, verticalAlign: 'center', horizontalAlign: "end", className: chatHeaderContainerStyle },
        React.createElement("div", { className: paneButtonContainerStyle },
            React.createElement(IconButton, { onRenderIcon: () => (props.isParticipantsDisplayed ? React.createElement(People20Filled, null) : React.createElement(People20Regular, null)), className: mergeStyles({ color: theme.palette.neutralPrimaryAlt }), onClick: () => props.setHideParticipants(props.isParticipantsDisplayed) })),
        React.createElement(DefaultButton, { className: mergeStyles(largeLeaveButtonContainerStyle, leaveButtonStyle, {
                color: theme.palette.neutralPrimaryAlt
            }), styles: buttonWithIconStyles, text: leaveString, onClick: () => props.onEndChat(), onRenderIcon: () => React.createElement(Icon, { iconName: leaveIcon.iconName, className: leaveIconStyle }), "aria-live": 'polite', "aria-label": leaveString }),
        React.createElement(IconButton, { iconProps: leaveIcon, className: mergeStyles(smallLeaveButtonContainerStyle, greyIconButtonStyle, {
                color: theme.palette.neutralPrimaryAlt
            }), onClick: () => props.onEndChat(), ariaLabel: leaveString, "aria-live": 'polite' })));
};
//# sourceMappingURL=ChatHeader.js.map