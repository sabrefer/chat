declare const _default: () => JSX.Element;
/**
 * HomeScreen has two states:
 * 1. Showing start chat button
 * 2. Showing spinner after clicking start chat
 *
 * @param props
 */
export default _default;
//# sourceMappingURL=HomeScreen.d.ts.map